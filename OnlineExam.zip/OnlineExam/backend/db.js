const mysql = require('mysql2/promise');

// Create a pool that supports promises
const db = mysql.createPool({
  host: 'localhost',       // your DB host
  user: 'root',            // your DB username
  password: 'root',// your DB password
  database: 'online',      // your DB name
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

module.exports = db;  // export the pool directly
