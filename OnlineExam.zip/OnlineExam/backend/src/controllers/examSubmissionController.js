let contro=require('../modals/examSubmissionModel');

exports.examsubmit = async (req, res) => {
  const { user_id, exam_id, answers } = req.body;

  if (!user_id || !exam_id || !answers) {
    return res.status(400).json({ msg: 'userid, examid and answers are required' });
  }
  if (!Array.isArray(answers) || answers.length === 0) {
    return res.status(400).json({ msg: 'answers must be a non-empty array' });
  }

  try {
    const result = await contro.submitExam(user_id, exam_id, answers);
    res.json({ msg: 'exam submitted successfully', result });
  } catch (err) {
    console.error('Error submitting exam:', err);
    res.status(500).json({ msg: 'Server error', error: err.message });
  }
};


