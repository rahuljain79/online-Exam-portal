// let express=require('express');
let model=require('../modals/scheduleModel');

exports.createSchedule = async (req, res) => {
    const { eid, s_time, end_time, status } = req.body;
    console.log({ eid, s_time, end_time, status });


    if (!eid || !s_time || !end_time) {
        return res.status(400).json({ msg: 'eid, s_time, and end_time are required' });
    }

    try {
        const result = await model.examExists(eid, s_time);
        
        if (result[0].count > 0) {
            return res.status(409).json({ msg: 'Duplicate schedule' });
        }

        const schedule_id = await model.addSchedule(eid, s_time, end_time, status || 'scheduled');
        return res.status(201).json({ schedule_id });

    } catch (err) {
        console.error(err);
        return res.status(500).json({ msg: 'Server error' });
    }
};


exports.getAllschedule=(req,res)=>{
    let promise=model.find();
  promise.then((rows)=>{
        res.json(rows);
    })
  promise.catch((err)=>{
        res.json({msg:err.message});
    })
}


exports.getscheduleByID=(req,res)=>{
    let {id}=req.body;
    let promise=model.getByID(id);
    promise.then(([rows])=>{
        res.json([rows]);
    })
    promise.catch((err)=>{
        res.json({msg:err})
    })
}

exports.updatescheduleByID=(req,res)=>{
    let id=req.query.id;
    let user=req.user;
    console.log('user making the request: ',user);
    
    let {eid,stime,etime,status}=req.body;
    let promise=model.updatebyID(id,eid,stime,etime,status);
    promise.then((result)=>{
        res.json({msg:'updation successfully done'});
    })
    promise.catch((err)=>{
        res.json({err:err.message});
    })
}

exports.deletescheduleById=(req,res)=>{
    let id=req.query.id;
    let p=model.delById(id);
    p.then((result)=>{
        res.json({msg:'deleted successfully'})
    })
    p.catch((err)=>{
        res.json({msg:err.message})
    })
}

exports.searchScheduleByDate = (req, res) => {
    let date = req.query.date;

    // Simple regex check for YYYY-MM-DD
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
        return res.json({ msg: 'Invalid or missing date format' });
    }

    model.searchdetailByDate(date)
        .then((result) => {
            if (result.length === 0) res.json({ msg: 'record not available' });
            else res.json(result);
        })
        .catch((err) => {
            res.status(500).json({ msg: 'something went wrong' });
        });
};
