let db=require('../../db');


exports.isregister = async (name, email, hashedpasswrd, role) => {
    console.log(name, email, hashedpasswrd, role);

    try {
        const [result] = await (await db).query(
            "INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)",
            [name, email, hashedpasswrd, role]
        );
        return result; // query ka result return karega
    } catch (err) {
        console.error("Error in isregister:", err);
        throw err; // caller ko error bhej de
    }
};



exports.iscorrect=(email)=>{
    return new Promise((resolve, reject) => {
        db.query('select * from users where email=?', [email], (err, result) => {
            if (err) {
                reject(err);
            }
            //  else if (result && result.length > 0) {
            //     resolve(true);}
             else {
                resolve(result);
            }
        });
    });
};