let db=require('../../db');

exports.assignexam=(examid,student_id)=>{
    return new Promise((resolve, reject) => {
        if (!examid || !student_id) {
            return reject(new Error('examid and student_id are required'));
        }
        db.query('insert into  exam_assignments (exam_id, student_id) VALUES (?, ?)',[examid, student_id], (err, result)=>{
            if (err) {
                return reject(err);
            }
            resolve(result);
        })}
)}

exports.getquestByID=(examid)=>{
    return new Promise((resolve, reject) => {
        if (!examid) {
            return reject(new Error('examid is required'));
        }
        db.query('select * from exam_assignments where exam_id=?', [examid], (err, result) => {
            if (err) {
                return reject(err);
            }
            resolve(result);
        });
    });
}


