let db=require('../../db.js');

exports.createques = (exam_id, question_text, option_a, option_b, option_c, option_d, correct_option) => {
    return new Promise((resolve, reject) => {
        db.query(
            "insert into questions (exam_id, question_text, option_a, option_b, option_c, option_d, correct_option) VALUES (?, ?, ?, ?, ?, ?, ?)",
            [exam_id, question_text, option_a, option_b, option_c, option_d, correct_option],
            (err, result) => {
                if (err) reject(err);
                else resolve(result);
            }
        );
    });
};

exports.getQues = () => {
   return new Promise((resolve,reject)=>{
        db.query('select * from questions ',(err,result)=>{
            if(err) reject(err);
            else resolve(result);
        });
    });
};

exports.getQuesByID = (id) => {
    return new Promise((resolve, reject) => {
        db.query('select * from questions where question_id=?', [id], (err, result) => {
            if (err) reject(err);
            else resolve(result);
        });
    });
}

exports.updatebyID=(id, exam_id, question_text, option_a, option_b, option_c, option_d, correct_option) => {
    return new Promise((resolve, reject) => {
        db.query(
            'update questions set exam_id=?, question_text=?, option_a=?, option_b=?, option_c=?, option_d=?, correct_option=? where question_id=?',
            [exam_id, question_text, option_a, option_b, option_c, option_d, correct_option, id],
            (err, result) => {
                if (err) reject(err);
                else resolve(result);
            }
        );
    });
}

exports.delById=(id)=>{
    return new Promise((resolve,reject)=>{
        db.query('delete from questions where question_id=?',[id],(err,result)=>{
            if(err) reject(err);
            else resolve(result);
        });
    });
}


exports.getQuestionsByCourseName = (courseName) => {
    return new Promise((resolve, reject) => {
        const sql = `
            SELECT q.*
            FROM courses c
            JOIN exams e ON c.course_id = e.course_id
            JOIN questions q ON e.exam_id = q.exam_id
            WHERE c.name = ?;
        `;
        db.query(sql, [courseName], (err, results) => {
            if (err) return reject(err);
            resolve(results);
        });
    });
};