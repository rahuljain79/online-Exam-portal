// let db=require('../../db');


// module.exports={
//     submitExam:(studentId,examId, ans)=>{
//         return new Promise((resolve, reject) => {

//             db.query('insert into submissions(student_id,exam_id) values(?,?)',[studentId,examId],(err,result)=>{
//                 if(err){
//                     return reject(err);
//                 }
//             }).then((result) => {
//                 let submissionId = result.insertId;
//                 let score=0;
//                 let promises=[];
//                 ans.forEach(answer =>{
//                     let p=db.query('select correct_option from questions where question_id=?',[answer.questionId]);
//                     p.then(([row])=>{
//                         let iscorrect=row[0].correct_option==answer.chosen_option;
//                          if(iscorrect){
//                             score++;
//                          }
//                           return db.query('insert into answers(submissionId,questionId,chosen_option,is_correct) values(?,?,?,?) ',[submissionId,answer.questionId,answer.chosen_option,iscorrect] )
//                 } );
//                 promises.push(p);
                
//         }
//     );
//  Promise.all(promiess)
//                 .then(() => {
//                     return db.query(
//                         "update submissions set score = ? where submission_id = ?", [score, submissionId],(err,result)  );
//                 })
//                 .then(() => {
//                     resolve({ score, total_questions: ans.length });
//                 })
//                 .catch(err => reject(err));
//             })
//             .catch(err => reject(err));
//         });
//     }
// }
        
const db = require('../../db');

module.exports = {
  submitExam: async (studentId, examId, answers) => {
    console.log(studentId + " " + examId);

    // 1. Check if submission already exists
    const [existing] = await db.query(
      'SELECT submission_id FROM submissions WHERE user_id = ? AND exam_id = ?',
      [studentId, examId]
    );

    if (existing.length > 0) {
      throw new Error('User has already submitted this exam');
    }

    // 2. Create a new submission row
    const [result] = await db.query(
      'INSERT INTO submissions (user_id, exam_id) VALUES (?, ?)',
      [studentId, examId]
    );
    const submissionId = result.insertId;

    // 3. Calculate score and insert answers
    let score = 0;

    for (const answer of answers) {
      const [rows] = await db.query(
        'SELECT correct_option FROM questions WHERE question_id = ?',
        [answer.question_id]
      );

      if (rows.length === 0) {
        throw new Error(`Question ID ${answer.question_id} not found`);
      }

      const isCorrect = rows[0].correct_option === answer.chosen_option;
      if (isCorrect) score++;

      await db.query(
        'INSERT INTO answers (submission_id, question_id, chosen_option, is_correct) VALUES (?, ?, ?, ?)',
        [submissionId, answer.question_id, answer.chosen_option, isCorrect]
      );
    }

    // 4. Update score in submissions
    await db.query(
      'UPDATE submissions SET score = ? WHERE submission_id = ?',
      [score, submissionId]
    );

    return { score, total_questions: answers.length };
  }
};
