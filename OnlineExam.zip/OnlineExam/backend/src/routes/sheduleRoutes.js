let express = require('express');
let router = express.Router();
let contro = require('../controllers/sheduleController');
// let {authenticateToken,isAdmin}=require('../middleware/authMidleware');
let {authenticateToken,isAdmin}=require("../middleware/authmidleware");

// router.put()
router.post('/scheduleadd',authenticateToken,isAdmin,contro.createSchedule);
router.get('/scheduleview',authenticateToken,isAdmin,contro.getAllschedule);
router.get('/scheduleById',authenticateToken,isAdmin,contro.getscheduleByID);
router.put('/updatescheuleByid',authenticateToken,isAdmin, contro.updatescheduleByID);
router.delete('/delshedule',authenticateToken,isAdmin,contro.deletescheduleById);
router.get('/searchscheduleByDate',authenticateToken,isAdmin,contro.searchScheduleByDate);





module.exports = router;