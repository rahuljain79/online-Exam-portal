
const express = require('express');
const router = express.Router();
console.log(" questionRoutes.js loaded");
const questionCtrl = require('../controllers/questionController');

// POST route to create a question
router.post('/createQuestions', questionCtrl.createQuestion);
router.get('/getQuestions', questionCtrl.getQuestions);
router.get('/getQuestionsByID', questionCtrl.getQuestionsByID); 
router.put('/updateQuestion',questionCtrl.updateQuestion);
router.delete("/deleteques",questionCtrl.Deleteques);
router.get('/searchque',questionCtrl.SearchQues);
router.get('/seachquesbycourse', questionCtrl.searchQuestionsByCourse);
// router.put('/updateQuestion', questionCtrl.updateQuestion);
// router.post('/createQuestions', (req, res) => {
//   console.log("✅ POST /createQuestions route hit");
//   res.send("Create Questions route works without controller.");
// });
// router.get('/test', (req, res) => {
//     console.log(" /api/test route hit");
//     res.send("Question routes are working");
// });

module.exports = router;