const express = require('express');
const router = express.Router();
let examassign=require('../controllers/examAssignController');
// let examsubmission=require('../controllers/examSubmissionController');


router.post('/assignquestion',examassign.assignexam);
router.get('/getQuesByExamId',examassign.getQuesByExamId);
// router.post('/examsubmit',examsubmission.examsubmit);
// const ExamController = require('../controllers/examAsignController');
// let {authenticateToken,isAdmin,isStudent}=require('../middleware/authMidleware');

// router.post('/assign-question', ExamController.assignQuestionToExam);
// router.get('/search-questions/:examName', ExamController.searchQuestionByExam);
// // Assignment routes
// router.post('/assign', ExamController.assignExam);
// router.get('/assigned-exams', ExamController.getAssignedExams);

// // Submission routes
// router.post('/submit', ExamController.submitExam);
// router.get('/result', ExamController.getExamResult);

module.exports = router;

