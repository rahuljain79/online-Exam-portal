let express=require('express');
let control=require('../controllers/courseController');
let router=express.Router();
let {authenticateToken,isAdmin}=require('../middleware/authmidleware');

router.post('/addcourse',authenticateToken,isAdmin,control.addCourse);
router.get('/viewcourse',authenticateToken,isAdmin,control.viewcourse);
router.get('/getcourseById',authenticateToken,isAdmin,control.getcourseById);
router.put('/updatecourse',authenticateToken,isAdmin,control.updatecourse);
router.delete('/deletecourse',authenticateToken,isAdmin,control.deletecourse);
router.get('/searchcourseByDate',authenticateToken,isAdmin,control.searchcourseByDate);



module.exports=router;