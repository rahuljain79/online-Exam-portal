const express = require('express');
const router = express.Router();

let examsubmission=require('../controllers/examSubmissionController');

console.log(" examSubmissionRouter.js loaded");
router.post('/examsubmit',examsubmission.examsubmit);



module.exports = router;