let app=require("./src/app");

app.listen(3000,()=>{
    console.log("server conneted");
})