let db=require('../../db');

exports.assignexam=(examid,questionid)=>{
    return new Promise((resolve, reject) => {
        if (!examid || !questionid) {
            return reject(new Error('examid and questionid are required'));
        }
        db.query('insert into  exam_assignments (exam_id, question_id) VALUES (?, ?)'[examid, questionid], (err, result)=>{
            if (err) {
                return reject(err);
            }
            resolve(result);
        })}
)}

exports.getquestByID=(examid)=>{
    return new Promise((resolve, reject) => {
        if (!examid) {
            return reject(new Error('examid is required'));
        }
        db.query('select * from exam_assignments where exam_id=?', [examid], (err, result) => {
            if (err) {
                return reject(err);
            }
            resolve(result);
        });
    });
}


