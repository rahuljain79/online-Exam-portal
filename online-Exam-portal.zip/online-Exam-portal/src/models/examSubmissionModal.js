// let db=require('../../db');


// module.exports={
//     submitExam:(studentId,examId, ans)=>{
//         return new Promise((resolve, reject) => {

//             db.query('insert into submissions(student_id,exam_id) values(?,?)',[studentId,examId],(err,result)=>{
//                 if(err){
//                     return reject(err);
//                 }
//             }).then((result) => {
//                 let submissionId = result.insertId;
//                 let score=0;
//                 let promises=[];
//                 ans.forEach(answer =>{
//                     let p=db.query('select correct_option from questions where question_id=?',[answer.questionId]);
//                     p.then(([row])=>{
//                         let iscorrect=row[0].correct_option==answer.chosen_option;
//                          if(iscorrect){
//                             score++;
//                          }
//                           return db.query('insert into answers(submissionId,questionId,chosen_option,is_correct) values(?,?,?,?) ',[submissionId,answer.questionId,answer.chosen_option,iscorrect] )
//                 } );
//                 promises.push(p);
                
//         }
//     );
//  Promise.all(promiess)
//                 .then(() => {
//                     return db.query(
//                         "update submissions set score = ? where submission_id = ?", [score, submissionId],(err,result)  );
//                 })
//                 .then(() => {
//                     resolve({ score, total_questions: ans.length });
//                 })
//                 .catch(err => reject(err));
//             })
//             .catch(err => reject(err));
//         });
//     }
// }
        

const db = require('../../db'); // Make sure this is mysql2/promise connection

module.exports = {
    submitExam: (studentId, examId, answers) => {
        return new Promise((resolve, reject) => {
            // Step 1: Insert into submissions
            db.query('INSERT INTO submissions (user_id, exam_id) VALUES (?, ?)', [studentId, examId])
            .then(([result]) => {
                const submissionId = result.insertId;
                let score = 0;
                let promises = [];

                // Step 2: Loop through answers
                answers.forEach(answer => {
                    const p = db.query('SELECT correct_option FROM questions WHERE question_id = ?', [answer.question_id])
                    .then(([rows]) => {
                        const isCorrect = rows[0].correct_option === answer.chosen_option;
                        if (isCorrect) score++;

                        // Insert answer
                        return db.query(
                            'INSERT INTO answers (submission_id, question_id, chosen_option, is_correct) VALUES (?, ?, ?, ?)',
                            [submissionId, answer.question_id, answer.chosen_option, isCorrect]
                        );
                    });
                    promises.push(p);
                });

                // Step 3: After all answers inserted, update score
                Promise.all(promises)
                .then(() => {
                    return db.query('UPDATE submissions SET score = ? WHERE submission_id = ?', [score, submissionId]);
                })
                .then(() => {
                    resolve({ score, total_questions: answers.length });
                })
                .catch(err => reject(err));
            })
            .catch(err => reject(err));
        });
    }
};
