let model = require('../models/quesModel');

exports.createQuestion = (req, res) => {
    // console.log("question controller hits.............");
    // res.json({ msg: "Controller is working fine" });
    const { exam_id, question_text, option_a, option_b, option_c, option_d, correct_option } = req.body;
    console.log(exam_id, question_text, option_a, option_b, option_c, option_d, correct_option);


    // if (!exam_id || !question_text || !option_a || !option_b || !option_c || !option_d || !correct_option) {
    //     return res.status(400).json({ msg: 'All fields are required.' });
    // }

    model.createques(exam_id, question_text, option_a, option_b, option_c, option_d, correct_option)
        .then(result => {
            console.log("hello.........");
            return res.status(201).json({ msg: 'Question created successfully', result });
        })
        .catch(err => {
            // console.error('Error inserting question:', err);
            if (!res.headersSent) {
                return res.status(500).json({
                    msg: "Server error",
                    error: err.message,
                });
            }
        });
};

exports.getQuestions=(req,res)=>{
    console.log("Fetching all questions...");
    let p= model.getQues()
       p.then((result)=>{
          return res.json(result);
       })
       p.catch((err)=>{
           return res.json({msg:err.message});
       });
}

exports.getQuestionsByID=(req, res)=>{
    let id = req.query.id;
    console.log("Fetching question with ID:", id);
    
    model.getQuesByID(id)
        .then(result => {
            if (result.length > 0) {
                return res.json(result[0]);
            } else {
                return res.status(404).json({ msg: 'Question not found' });
            }
        })
        .catch(err => {
            console.error('Error fetching question:', err);
            return res.status(500).json({
                msg: "Server error",
                error: err.message,
            });
        });
}

exports.updateQuestion = (req, res) => {
       let id=req.query.id;
        // let user=req.user;
        // console.log('user making the request: ',user);
        
        let {exam_id, question_text, option_a, option_b, option_c, option_d, correct_option } = req.body;
        let promise=model.updatebyID( id, exam_id, question_text, option_a, option_b, option_c, option_d, correct_option );
        promise.then((result)=>{
            res.json({msg:'updation successfully done'});
        })
        promise.catch((err)=>{
            res.json({err:err.message});
        })
}

exports.Deleteques=(req, res)=>{
    let id=req.query.id;
    console.log("Deleting question with ID:", id);
    
    model.delById(id)
        .then(result => {
            return res.json({ msg: 'Question deleted successfully' });
        })
        .catch(err => {
            console.error('Error deleting question:', err);
            return res.status(500).json({
                msg: "Server error",
                error: err.message,
            });
        });
}

exports.SearchQues=(req, res)=>{
    let question_text= req.query.question_text;
    console.log("Searching for question:", question_text);
    model.getQues()
        .then(result => {
            const filteredQuestions = result.filter(q => q.question_text.includes(question_text));
            if (filteredQuestions.length > 0) {
                return res.json(filteredQuestions);
            } else {
                return res.status(404).json({ msg: 'No questions found matching the search term' });
            }
        })
        .catch(err => {
            console.error('Error searching questions:', err);
            return res.status(500).json({
                msg: "Server error",
                error: err.message,
            });
        });
}

exports.searchQuestionsByCourse = (req, res) => {
    const { name } = req.query;
    if (!name) {
        return res.status(400).json({ msg: "Course name is required" });
    }

    model.getQuestionsByCourseName(name)
        .then((questions) => {
            if (questions.length === 0) {
                return res.status(404).json({ msg: "No questions found for this course" });
            }
            res.status(200).json({ course: name, questions });
        })
        .catch((err) => {
            console.error(err);
            res.status(500).json({ msg: "Server error", error: err.message });
        });
};