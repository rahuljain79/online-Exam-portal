let contro=require('../models/examSubmissionModal');

exports.examsubmit= async (req, res) => {
    const { user_id, exam_id, answers } = req.body;
    if(!exam_id || !answers || !user_id){
        return res.status(400).json({msg:' userid examid and answer are required'});
    }
    let p= await contro.submitExam(user_id,exam_id,answers);
    p.then((result)=>{
        res.json({msg:'exam submitted successfully'});
    })
    p.catch((err)=>{
        console.error('Error submitting exam:', err);
        res.status(500).json({msg:'Server error', error: err.message});
    }
    );
}

