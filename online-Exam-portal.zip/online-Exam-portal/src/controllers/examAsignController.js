let express = require('express');
let control = require('../models/examAssignModal');


exports.assignexam= (req, res)=>{
    let {examid,questionid}= req.body;
    if(!examid || !questionid){
        return res.json({msg:'examid and questionid are required'});
    }
    control.assignexam(examid,questionid)
        .then((result)=>{
            res.json({msg:'question assigned successfully'});
        })
        .catch((err)=>{
            res.json({error:err.message});
        });
}

exports.getQuesByExamId = (req, res) => {
    let examid = req.query.examid;
    if (!examid) {
        return res.status(400).json({ msg: 'examid is required' });
    }
    
    control.getquestByID(examid)
    .then((result) => {
        if (result.length > 0) {
            return res.json(result);
        } else {
            return res.status(404).json({ msg: 'No questions found for this exam' });
        }
    }
    )
    .catch((err) => {
        console.error('Error fetching questions:', err);
        return res.status(500).json({
            msg: "Server error",
            error: err.message,
        });
    })};