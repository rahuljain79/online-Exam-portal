const express = require('express');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/auth'); // Not relevant to schedule
let scheduled = require('./routes/sheduleRoutes');
let userRoute=require('./routes/userRoutes');
let course=require('./routes/courseRoutes');
let exam=require('./routes/examRoutes');
let questions=require('./routes/QuestionRoutes');
let examassign=require('./routes/examAssignRoute');
let examsubmit=require('./routes/examSubmissionRouter');
let cors=require('cors');

// const router = express.Router();
const app = express();
const corsOptions = {
    origin: 'http://localhost:5173', 
    methods: ['GET,POST','PUT','DELETE'], 
    allowedHeaders: ['Content-Type', 'Authorization'] 
};
app.use(cors(corsOptions))

app.use(bodyParser.urlencoded({extended:true}));
app.use(express.json());
app.use('/api', authRoutes);
app.use('/api', scheduled);
app.use('/user',userRoute);
app.use('/api',course);
app.use('/api',exam);
console.log(" questionRoutes imported");
app.use('/api',questions);
app.use('/api',examassign);
app.use('/api', examsubmit);

// router.post('/createQts',qustCtrl.createQuestion);


module.exports = app;

/*
implemented crud operation of schedule course and exam
*/