let mysql=require('mysql2');


let conn=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'root',
    database:'onlineexam'
})

conn.connect((err)=>{
    if(err)
        console.log("something went wrong");
    else
        console.log("connected");
}
)
module.exports=conn;

// const mysql = require('mysql2/promise');
// const db = mysql.createPool({
//   host: 'localhost',
//   user: 'root',
//   password: 'password',
//   database: 'OnlineExam'
// });
// module.exports = db;
