let app=require("./src/app.js");

app.listen(5000,()=>{
    console.log("server conneted");
})